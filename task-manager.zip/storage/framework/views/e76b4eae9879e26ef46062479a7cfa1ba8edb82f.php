<?php $__env->startSection('content'); ?>



    <div class="container p-5">
        <div class="row">
            <div class="col-lg-12">

                <div class="pb-3">
                    <div class="float-start">
                        <h4>My Task</h4>
                    </div>
                    <div class="float-end">
                        <a href="<?php echo e(route("task.create")); ?>" class="btn btn-success">
                           <i class="fa fa-plus-circle"></i> Create Task
                        </a>
                    </div>
                    <div class="clearfix"></div>
                </div>

                <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <h5 class="card-header">
                        <?php if($task->status === "Todo"): ?>
                            <?php echo e($task->title); ?>

                            <?php else: ?>
                            <del><?php echo e($task->title); ?></del>
                            <?php endif; ?>

                        <span class="badge rounded-pill bg-warning text-dark ms-1">
                            <?php echo e($task->created_at->diffforHumans()); ?>

                        </span>
                    </h5>

                    <div class="card-body">
                        <div class="card-text">
                            <div class="float-start">
                            <?php if($task->status === "Todo"): ?>
                            <?php echo e($task->description); ?>

                            <?php else: ?>
                            <del><?php echo e($task->description); ?></del>
                            <?php endif; ?>
                            <br>

                            <?php if($task->status === "Todo"): ?>
                            <span class="badge rounded-pill bg-info text-dark my-3">
                                Todo
                            </span>
                            <?php else: ?>
                            <span class="badge rounded-pill bg-dark text-white my-3">
                                Done
                            </span>
                            <?php endif; ?>

                            <small>Last Updated - <?php echo e($task->updated_at->diffforHumans()); ?> </small>
                            </div>

                            <div class="float-end">
                                <a href="<?php echo e(route("task.edit", $task->id)); ?>" class="btn btn-primary">
                                    Edit
                                </a>
                                <form action="<?php echo e(route("task.destroy", $task->id)); ?>" style="display:inline;" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                            <div class="clearfix"></div>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Task-Manager\resources\views/index.blade.php ENDPATH**/ ?>