<?php $__env->startSection('content'); ?>



    <div class="container p-5">
        <div class="row">
            <div class="col-lg-12">

                <div class="pb-3">
                    <div class="float-start">
                        <h4>Create Task</h4>
                    </div>
                    <div class="float-end">
                        <a href="<?php echo e(route("task.index")); ?>" class="btn btn-success">
                            All Task
                        </a>
                    </div>
                    <div class="clearfix"></div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problem with your fields... <br><br>

                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li><?php echo e($error); ?></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>


                <div class="card card-body bg-light p-4">
                    <form action="<?php echo e(route("task.store")); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <label for="text" class="form-label">Title</label>
                          <input type="text" class="form-control" id="title" name="title" placeholder="eg: (...)">
                        </div>

                        <div class="mb-3">
                          <label for="description" class="form-label">Description</label>
                          <textarea type="text" class="form-control" id="description" name="description" rows="5" placeholder="eg: (...)"></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="text" class="form-label">Status</label>
                            <select name="status" id="status" class="form-control">
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status['value']); ?>"><?php echo e($status['label']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                      </form>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Task-Manager\resources\views/create.blade.php ENDPATH**/ ?>